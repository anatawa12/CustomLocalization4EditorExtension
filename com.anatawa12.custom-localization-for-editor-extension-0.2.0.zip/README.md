Custom Localization for Editor Extension
===

A experimental library for Unity extensions which want to have custom locale for translation instead of unity's locale. 

## What's this?

In Japan, it also be general to use English for unity's locale because many useful information are on foreign countries and they uses English.
But for tools by Japanese, We may use Japanese because documentation may use Japanese.
So, I make a localization library to choose locale for each editor extension.

